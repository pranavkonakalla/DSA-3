package com.recommendation.engine.dsa;
import com.recommendation.engine.model.Movie;
import java.util.HashMap;
import java.util.Map;
public class MovieHashTable {
 private final Map<String,Movie> table=new HashMap<>();
 public void put(Movie movie){table.put(movie.getTitle().toLowerCase(),movie);}
 public Movie get(String title){return table.get(title.toLowerCase());}
 public int size(){return table.size();}
}