package com.recommendation.engine.model;
public class Recommendation {
 private Movie movie; private double score; private String reason;
 public Recommendation(){}
 public Recommendation(Movie movie,double score,String reason){this.movie=movie;this.score=score;this.reason=reason;}
 public Movie getMovie(){return movie;} public void setMovie(Movie movie){this.movie=movie;}
 public double getScore(){return score;} public void setScore(double score){this.score=score;}
 public String getReason(){return reason;} public void setReason(String reason){this.reason=reason;}
}