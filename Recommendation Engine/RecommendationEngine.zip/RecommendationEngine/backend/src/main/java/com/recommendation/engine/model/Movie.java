package com.recommendation.engine.model;
public class Movie {
 private int id; private String title; private String genre; private double rating; private int year;
 public Movie(){}
 public Movie(int id,String title,String genre,double rating,int year){this.id=id;this.title=title;this.genre=genre;this.rating=rating;this.year=year;}
 public int getId(){return id;} public void setId(int id){this.id=id;}
 public String getTitle(){return title;} public void setTitle(String title){this.title=title;}
 public String getGenre(){return genre;} public void setGenre(String genre){this.genre=genre;}
 public double getRating(){return rating;} public void setRating(double rating){this.rating=rating;}
 public int getYear(){return year;} public void setYear(int year){this.year=year;}
}