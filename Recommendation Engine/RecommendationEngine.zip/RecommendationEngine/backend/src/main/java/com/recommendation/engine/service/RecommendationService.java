package com.recommendation.engine.service;
import com.recommendation.engine.dsa.*;
import com.recommendation.engine.model.*;
import org.springframework.stereotype.Service;
import jakarta.annotation.PostConstruct;
import java.io.*;
import java.util.*;
@Service
public class RecommendationService {
 private final List<Movie> movies=new ArrayList<>();
 private final MovieHashTable movieTable=new MovieHashTable();

 @PostConstruct
 public void loadMovies(){
  try(BufferedReader reader=new BufferedReader(new InputStreamReader(getClass().getResourceAsStream("/movies.csv")))){
   String line; reader.readLine();
   while((line=reader.readLine())!=null){
    String[] p=line.split(",",-1);
    Movie m=new Movie(Integer.parseInt(p[0]),p[1],p[2],Double.parseDouble(p[3]),Integer.parseInt(p[4]));
    movies.add(m); movieTable.put(m);
   }
  }catch(Exception e){throw new IllegalStateException("Unable to load movies.csv",e);}
 }

 public List<Movie> getMovies(){return movies;}
 public List<String> getAlgorithms(){return List.of("Hash Table","Linear Search","Insertion Sort","Max Heap");}

 public List<Recommendation> recommend(String title,int limit){
  Movie selected=SearchAlgorithm.linearSearch(movies,title);
  if(selected==null)return List.of();
  MaxHeap heap=new MaxHeap();
  for(Movie movie:movies){
   if(movie.getId()==selected.getId())continue;
   double score=similarity(selected,movie);
   heap.add(new Recommendation(movie,Math.round(score*100.0)/100.0,"Similar genre and rating"));
  }
  List<Recommendation> result=new ArrayList<>();
  while(!heap.isEmpty() && result.size()<Math.max(1,limit))result.add(heap.poll());
  return result;
 }

 private double similarity(Movie a,Movie b){
  double genreScore=a.getGenre().equalsIgnoreCase(b.getGenre())?70:0;
  double ratingScore=Math.max(0,30-Math.abs(a.getRating()-b.getRating())*10);
  return genreScore+ratingScore;
 }
}