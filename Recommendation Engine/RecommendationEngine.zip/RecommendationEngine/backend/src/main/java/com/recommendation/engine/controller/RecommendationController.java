package com.recommendation.engine.controller;
import com.recommendation.engine.model.*;
import com.recommendation.engine.service.RecommendationService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api")
@CrossOrigin(origins="*")
public class RecommendationController {
 private final RecommendationService service;
 public RecommendationController(RecommendationService service){this.service=service;}
 @GetMapping("/movies") public List<Movie> movies(){return service.getMovies();}
 @GetMapping("/recommendations") public List<Recommendation> recommendations(@RequestParam(defaultValue="Inception") String movie,@RequestParam(defaultValue="5") int limit){return service.recommend(movie,limit);}
 @GetMapping("/algorithms") public List<String> algorithms(){return service.getAlgorithms();}
}