package com.recommendation.engine.dsa;
import com.recommendation.engine.model.Recommendation;
import java.util.PriorityQueue;
public class MaxHeap {
 private final PriorityQueue<Recommendation> heap=new PriorityQueue<>((a,b)->Double.compare(b.getScore(),a.getScore()));
 public void add(Recommendation r){heap.add(r);}
 public Recommendation poll(){return heap.poll();}
 public boolean isEmpty(){return heap.isEmpty();}
}