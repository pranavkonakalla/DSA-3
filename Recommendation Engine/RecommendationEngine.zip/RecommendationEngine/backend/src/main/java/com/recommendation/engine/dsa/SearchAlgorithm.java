package com.recommendation.engine.dsa;
import com.recommendation.engine.model.Movie;
import java.util.List;
public class SearchAlgorithm {
 public static Movie linearSearch(List<Movie> movies,String title){
  for(Movie movie:movies) if(movie.getTitle().equalsIgnoreCase(title)) return movie;
  return null;
 }
}