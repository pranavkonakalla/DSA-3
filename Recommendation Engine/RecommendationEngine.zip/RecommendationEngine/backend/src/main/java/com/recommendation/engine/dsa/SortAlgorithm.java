package com.recommendation.engine.dsa;
import com.recommendation.engine.model.Movie;
import java.util.ArrayList;
import java.util.List;
public class SortAlgorithm {
 public static List<Movie> sortByRating(List<Movie> movies){
  List<Movie> result=new ArrayList<>(movies);
  for(int i=1;i<result.size();i++){
   Movie key=result.get(i); int j=i-1;
   while(j>=0 && result.get(j).getRating()<key.getRating()){result.set(j+1,result.get(j));j--;}
   result.set(j+1,key);
  }
  return result;
 }
}