const API="http://localhost:8080/api";
async function loadMovies(){
 const res=await fetch(API+"/movies"); const movies=await res.json();
 const select=document.getElementById("movieSelect");
 if(select) select.innerHTML=movies.map(m=>`<option value="${m.title}">${m.title}</option>`).join("");
 const dataset=document.getElementById("dataset");
 if(dataset) dataset.innerHTML="<table><thead><tr><th>ID</th><th>Title</th><th>Genre</th><th>Rating</th><th>Year</th></tr></thead><tbody>"+movies.map(m=>`<tr><td>${m.id}</td><td>${m.title}</td><td>${m.genre}</td><td>${m.rating}</td><td>${m.year}</td></tr>`).join("")+"</tbody></table>";
}
async function getRecommendations(){
 const movie=document.getElementById("movieSelect").value;
 const limit=document.getElementById("limit").value;
 const box=document.getElementById("recommendations"); box.innerHTML="<p>Loading...</p>";
 try{
  const res=await fetch(`${API}/recommendations?movie=${encodeURIComponent(movie)}&limit=${limit}`);
  const data=await res.json();
  box.innerHTML=data.map(r=>`<div class="card"><h2>${r.movie.title}</h2><p>${r.movie.genre} • ${r.movie.year}</p><p class="score">Score: ${r.score}</p><p>${r.reason}</p></div>`).join("");
 }catch(e){box.innerHTML='<div class="card"><p>Start the Spring Boot backend on port 8080 first.</p></div>';}
}
document.addEventListener("DOMContentLoaded",loadMovies);